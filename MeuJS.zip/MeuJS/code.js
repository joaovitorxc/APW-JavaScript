
function imprime(){


    let lg = document.getElementById("login").value 
    let ps = document.getElementById("pass").value

let senha = "snoopy"

if(ps == senha){
    alert("Você está logado!")
}
    alert("Você está logado !")
}